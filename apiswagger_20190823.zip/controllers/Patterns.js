'use strict';

var utils = require('../utils/writer.js');
var Patterns = require('../service/PatternsService');

module.exports.addPatterns = function addPatterns (req, res, next) {
  var config = req.swagger.params['config'].value;
  Patterns.addPatterns(config)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deletePatterns = function deletePatterns (req, res, next) {
  Patterns.deletePatterns()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deletePatternsFile = function deletePatternsFile (req, res, next) {
  var file = req.swagger.params['file'].value;
  Patterns.deletePatternsFile(file)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deletePatternsFolder = function deletePatternsFolder (req, res, next) {
  var folder = req.swagger.params['folder'].value;
  Patterns.deletePatternsFolder(folder)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getPatternsFile = function getPatternsFile (req, res, next) {
  var file = req.swagger.params['file'].value;
  Patterns.getPatternsFile(file)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.patternslistConfig = function patternslistConfig (req, res, next) {
  Patterns.patternslistConfig()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updatePatterns = function updatePatterns (req, res, next) {
  var config = req.swagger.params['config'].value;
  Patterns.updatePatterns(config)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
